package com.pgd.poc.msdistancespringreactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsDistanceSpringReactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsDistanceSpringReactiveApplication.class, args);
	}

}

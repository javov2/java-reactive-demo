package com.pgd.poc.msdistancespringsync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsDistanceSpringSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsDistanceSpringSyncApplication.class, args);
	}

}

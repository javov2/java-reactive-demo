package com.pgd.poc.msdistancespringsync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsDistanceSpringSyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
